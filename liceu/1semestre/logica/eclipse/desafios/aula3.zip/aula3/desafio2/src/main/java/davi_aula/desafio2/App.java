package davi_aula.desafio2;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args0 ){
        
    	Scanner scanner = new Scanner(System.in);
    	
    	for (int contador = 10 ; contador>=1; contador--) {
    		System.out.println("numero: " + contador);
    	} 
    	
    }
}
