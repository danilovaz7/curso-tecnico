package davi_aula.desafio9;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args0 ){
        
    	Scanner scanner = new Scanner(System.in);
    	
    	System.out.println("deseja comprar alguma mercadoria?");
    	String pergunta = scanner.nextLine();
    	
    	int valorMerc;
    	
    	if(pergunta.equals("s")) {
    		System.out.println("insira o valor da mercadoria");
    		valorMerc = scanner.nextInt();
    		scanner.nextLine();
    		System.out.println("mercadoria adicionada, valor: " +valorMerc);
    	}
    	
    	
    
    	
    }
}
