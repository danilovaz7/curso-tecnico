package davi_aulas.urna_final;

import java.util.ArrayList;
import java.util.List;

public class Chapa {

	public String nome;
	public int votos = 0;
	public List<Integrante>integrantes = new ArrayList<>();
	
}
