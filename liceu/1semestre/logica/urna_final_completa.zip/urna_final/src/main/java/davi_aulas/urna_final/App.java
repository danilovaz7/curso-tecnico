package davi_aulas.urna_final;

public class App {

	public static void main(String[] args) {
		Urna urna = new Urna();
		urna.iniciarUrna();
	}
	
}
