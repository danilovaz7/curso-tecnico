package davi_aulas.urna_final;

public class Integrante {

	public String nome;
	public String cargo;

}
