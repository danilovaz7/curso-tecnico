package trabalho.trabalho_final.testing;

import org.testng.annotations.Test;

public class AppTest {

	@Test
	public void test() {
		assert Boolean.TRUE;
	}
	
}
