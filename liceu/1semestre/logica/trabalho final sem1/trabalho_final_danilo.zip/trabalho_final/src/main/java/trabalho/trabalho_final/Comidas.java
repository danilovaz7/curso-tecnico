package trabalho.trabalho_final;

public class Comidas {
	
	public String nome;
	public float preco;

}
