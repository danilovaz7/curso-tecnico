package trabalho.trabalho_final;

public class App {

	public static void main(String[] args) {
		Comanda comanda = new Comanda();
		comanda.iniciarComanda();
	}
	
}

